from django.apps import AppConfig


class FacultyappConfig(AppConfig):
    name = 'FacultyApp'
